#include "StageSelectScene.h"

#include "../../Utility/Utility.h"

#include "../../Application/Application.h"

#include "../../Manager/Input/InputManager.h"
#include "../../Manager/Sound/SoundManager.h"
#include "../../Manager/Font/FontManager.h"

#include "../SceneManager.h"

StageSelectScene::StageSelectScene() : SceneBase()
{
}

void StageSelectScene::SubPostLoad(void)
{
	// �����̃V�[���؂�ւ�
	Snd::GetIns().ChangeScene("StageSelect");
}

void StageSelectScene::SubPostUpdate(void)
{
	// �Q�[���I������
	if (Input::GetIns().GetInfo(KEY_TYPE::End).down) {
		App::GetIns().GameEnd();
	}

	// ����
	if (Input::GetIns().GetInfo(KEY_TYPE::Enter).down) {
		SceneManager::GetIns().ChangeSceneFade(SCENE_ID::Game);
	}
}

void StageSelectScene::SubUiDraw(void)
{
	DrawStringToHandle(0, 0, "�X�e�[�W�Z���N�g", 0xffffff, Font::GetIns().GetFont(FontKinds::Marumiya40));
}