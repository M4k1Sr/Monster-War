#pragma once

// �����^�C�v
enum class COLLIDER_MOBILITY { Static, Movable };

// �`��񋓌^��`
enum class COLLIDER_SHAPE
{
	None = -1,

	Line,
	Sphere,
	Capsule,
	Box,
	Mesh,
	XzCircle,
};

// �R���C�_�[�^�O�񋓌^��`
enum class COLLIDER_TAG
{
	None = -1,

	Player,
	PlayerAttackSlash,
	PlayerRollingSlash,
	PlayerRushSlash,
	PlayerKickDownAttack,
	Playerdodge,

	PlayerWeaponItem,

	Enemy,
	GobKingSwing,

	Stage,
	WindMill,
	IceStage,
	Water,

	Goal,

	CameraPoint,
	CameraLine,

	DebugObject,
};