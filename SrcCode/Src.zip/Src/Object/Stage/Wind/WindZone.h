#pragma once
#include "../../../Object/Common/ActorBase/ActorBase.h"

struct WindZoneParam {
	Vector3 startPos;
	Vector3 endPos;
	Vector3 windDir;
	float radius;
	bool isParaseilOnWind;
};

class WindZone
	: public ActorBase
{
public:
	WindZone(const WindZoneParam& param);
	~WindZone()override = default;

	// �ǂݍ��ݏ���
	void Load(void)override;

private:

	WindZoneParam param;

	// ���ƂƂȂ郂�f��
	int originModel;

	// ���f�����K�v�ȑ䐔
	int modelCount;

	// �H�̉�]�p
	float spinAngle;
	Quaternion baseQuaternion;


	// �X�V
	void SubUpdate(void)override;

	// ���
	void SubRelease(void)override;
};
